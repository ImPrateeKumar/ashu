package com.tmk.hibernate.constants;

public final class CommonConstants {

	public static final String BIBA_STRING = "BIBA";
	public static final String BIBA = "D0650594-CALL-4842-BA1B-F3397FED25D9";
	public static final String NEW_BIBA = "";
	public static final String NEW_BROKER_ADDED_MESSAGE = "";
	public static final String BROKER_NAME_OR_RB_TEAM_NAME_ALREADY_EXIST_MESSAGE = "";
	public static final String RULEBOOK_TEAM_NAME_ALREADY_EXISTS_MESSAGE = "";
	public static final String BROKER_LOCATION_ADDED_MESSAGE = "";
	public static final String BROKER_LOCATION_OR_RB_TEAM_NAME_ALREADY_EXIST_MESSAGE = "";
	public static final String BROKER_SUCESSFULLY_UPDATED_MESSAGE = "";
	public static final String LOCATION_ALREADY_EXISTS_FOR_BROKER = "";
}
