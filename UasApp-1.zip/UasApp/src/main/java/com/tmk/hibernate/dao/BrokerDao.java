package com.tmk.hibernate.dao;

import java.util.List;

import com.tmk.hibernate.annotations.BrokerGroup;

public interface BrokerDao {

	List<BrokerGroup> getBrokers(String brokerEntityName, String brokerLocation);

	String addBroker(String ruleBookTeamName, String brokerName, String location, String brokerType);

	String updateBroker(String ruleBookTeamName, String brokerName, String location, String brokerType,
			Integer brokerEntityId, Integer brokerGroupId, String ruleBookTeamNameTracker);

	String addBrokerLocation(String ruleBookTeamName, String brokerType, Integer brokerEntityId, String newLocation);

}
